<?php 
	
	$CI = &get_instance();
	echo current_url();die;

?>