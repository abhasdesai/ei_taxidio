<div class="container-fluid get-your-guides-list" id="scriptsearchedattractions">
	<div class="search-attractions">

	 
	  <div class="container">
      <div class="row">
 <div id="gyg-widget-5878d7c05f28e"></div><script async defer src="//widget.getyourguide.com/v2/core.js" onload="GYG.Widget(document.getElementById('gyg-widget-5878d7c05f28e'),{'currency':'USD','localeCode':'en-US','partnerId':'4SS3131','q':'Mumbai'});"></script>

 </div>
 </div>
 </div>
