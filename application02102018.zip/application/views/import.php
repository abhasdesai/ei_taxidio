<?php echo form_open('developer/importfile', array('id' => 'form1', 'enctype' => 'multipart/form-data')); ?>


<input type="file" name="excel">


<input type="submit">




</form>