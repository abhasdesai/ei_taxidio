<div class="container-fluid hotel-list">
  <div class="container">
      <div class="row">
        <div class="single-hotel-wrapper">
          <div class="col-md-12 no-padding hotel-name">
              <h3>Hotel du Collectionneur Arc de Triomphe</h3>
            </div>
            <div class="col-md-3 padding-left-0">
              <img src="<?php echo site_url('assets/images/hotel-1.jpg') ?>" width="100%" alt="" class="img-responsive hotel-img"/>
                <p class="hotel-address"><span>Address : </span>Rue de, Courcelles,<br/>75008 Paris, France.</p>
                <a href="#" class="link-button-small">Show On Map<i class="fa fa-map-marker" aria-hidden="true"></i></a>
            </div>
            <div class="col-md-3 text-center">
              <span class="best-price">Best Price</span>
                <p class="amenity-1">Single Room - Free cancellation</p>
                <p class="breakfast">Breakfast included</p>
                <span class="price-for-hotels"><span>INR 10,347.00</span><br/>Price for 2 nights</span>
            </div>
      <div class="col-md-3 text-center">
              <span class="popular-package">Popular</span>
                <p class="amenity-1">Single Room - Free cancellation</p>
                <p class="breakfast">Breakfast included</p>
                <span class="price-for-hotels"><span>INR 10,347.00</span><br/>Price for 2 nights</span>
            </div>
      <div class="col-md-3 text-center reviews">
              <p class="customer-reviews"><a href="#">Customer Reviews</a></p>
                <a href="#" class="link-button-small">Book Hotel<i class="fa fa-map-marker" aria-hidden="true"></i></a>
                <a href="#" class="link-button-small">View Details<i class="fa fa-map-marker" aria-hidden="true"></i></a>
            </div>
    </div>
        
        <div class="single-hotel-wrapper">
          <div class="col-md-12 no-padding hotel-name">
              <h3>Hotel du Collectionneur Arc de Triomphe</h3>
            </div>
            <div class="col-md-3 padding-left-0">
              <img src="<?php echo site_url('assets/images/hotel-1.jpg') ?>" width="100%" alt="" class="img-responsive hotel-img"/>
                <p class="hotel-address"><span>Address : </span>Rue de, Courcelles,<br/>75008 Paris, France.</p>
                <a href="#" class="link-button-small">Show On Map<i class="fa fa-map-marker" aria-hidden="true"></i></a>
            </div>
            <div class="col-md-3 text-center">
              <span class="best-price">Best Price</span>
                <p class="amenity-1">Single Room - Free cancellation</p>
                <p class="breakfast">Breakfast included</p>
                <span class="price-for-hotels"><span>INR 10,347.00</span><br/>Price for 2 nights</span>
            </div>
      <div class="col-md-3 text-center">
              <span class="popular-package">Popular</span>
                <p class="amenity-1">Single Room - Free cancellation</p>
                <p class="breakfast">Breakfast included</p>
                <span class="price-for-hotels"><span>INR 10,347.00</span><br/>Price for 2 nights</span>
            </div>
      <div class="col-md-3 text-center reviews">
              <p class="customer-reviews"><a href="#">Customer Reviews</a></p>
                <a href="#" class="link-button-small">Book Hotel<i class="fa fa-map-marker" aria-hidden="true"></i></a>
                <a href="#" class="link-button-small">View Details<i class="fa fa-map-marker" aria-hidden="true"></i></a>
            </div>
    </div>
        
        <div class="single-hotel-wrapper">
          <div class="col-md-12 no-padding hotel-name">
              <h3>Hotel du Collectionneur Arc de Triomphe</h3>
            </div>
            <div class="col-md-3 padding-left-0">
              <img src="<?php echo site_url('assets/images/hotel-1.jpg') ?>" width="100%" alt="" class="img-responsive hotel-img"/>
                <p class="hotel-address"><span>Address : </span>Rue de, Courcelles,<br/>75008 Paris, France.</p>
                <a href="#" class="link-button-small">Show On Map<i class="fa fa-map-marker" aria-hidden="true"></i></a>
            </div>
            <div class="col-md-3 text-center">
              <span class="best-price">Best Price</span>
                <p class="amenity-1">Single Room - Free cancellation</p>
                <p class="breakfast">Breakfast included</p>
                <span class="price-for-hotels"><span>INR 10,347.00</span><br/>Price for 2 nights</span>
            </div>
      <div class="col-md-3 text-center">
              <span class="popular-package">Popular</span>
                <p class="amenity-1">Single Room - Free cancellation</p>
                <p class="breakfast">Breakfast included</p>
                <span class="price-for-hotels"><span>INR 10,347.00</span><br/>Price for 2 nights</span>
            </div>
      <div class="col-md-3 text-center reviews">
              <p class="customer-reviews"><a href="#">Customer Reviews</a></p>
                <a href="#" class="link-button-small">Book Hotel<i class="fa fa-map-marker" aria-hidden="true"></i></a>
                <a href="#" class="link-button-small">View Details<i class="fa fa-map-marker" aria-hidden="true"></i></a>
            </div>
    </div>
        
        <div class="single-hotel-wrapper">
          <div class="col-md-12 no-padding hotel-name">
              <h3>Hotel du Collectionneur Arc de Triomphe</h3>
            </div>
            <div class="col-md-3 padding-left-0">
              <img src="<?php echo site_url('assets/images/hotel-1.jpg') ?>" width="100%" alt="" class="img-responsive hotel-img"/>
                <p class="hotel-address"><span>Address : </span>Rue de, Courcelles,<br/>75008 Paris, France.</p>
                <a href="#" class="link-button-small">Show On Map<i class="fa fa-map-marker" aria-hidden="true"></i></a>
            </div>
            <div class="col-md-3 text-center">
              <span class="best-price">Best Price</span>
                <p class="amenity-1">Single Room - Free cancellation</p>
                <p class="breakfast">Breakfast included</p>
                <span class="price-for-hotels"><span>INR 10,347.00</span><br/>Price for 2 nights</span>
            </div>
      <div class="col-md-3 text-center">
              <span class="popular-package">Popular</span>
                <p class="amenity-1">Single Room - Free cancellation</p>
                <p class="breakfast">Breakfast included</p>
                <span class="price-for-hotels"><span>INR 10,347.00</span><br/>Price for 2 nights</span>
            </div>
      <div class="col-md-3 text-center reviews">
              <p class="customer-reviews"><a href="#">Customer Reviews</a></p>
                <a href="#" class="link-button-small">Book Hotel<i class="fa fa-map-marker" aria-hidden="true"></i></a>
                <a href="#" class="link-button-small">View Details<i class="fa fa-map-marker" aria-hidden="true"></i></a>
            </div>
    </div>
        
        <div class="single-hotel-wrapper">
          <div class="col-md-12 no-padding hotel-name">
              <h3>Hotel du Collectionneur Arc de Triomphe</h3>
            </div>
            <div class="col-md-3 padding-left-0">
              <img src="<?php echo site_url('assets/images/hotel-1.jpg') ?>" width="100%" alt="" class="img-responsive hotel-img"/>
                <p class="hotel-address"><span>Address : </span>Rue de, Courcelles,<br/>75008 Paris, France.</p>
                <a href="#" class="link-button-small">Show On Map<i class="fa fa-map-marker" aria-hidden="true"></i></a>
            </div>
            <div class="col-md-3 text-center">
              <span class="best-price">Best Price</span>
                <p class="amenity-1">Single Room - Free cancellation</p>
                <p class="breakfast">Breakfast included</p>
                <span class="price-for-hotels"><span>INR 10,347.00</span><br/>Price for 2 nights</span>
            </div>
      <div class="col-md-3 text-center">
              <span class="popular-package">Popular</span>
                <p class="amenity-1">Single Room - Free cancellation</p>
                <p class="breakfast">Breakfast included</p>
                <span class="price-for-hotels"><span>INR 10,347.00</span><br/>Price for 2 nights</span>
            </div>
      <div class="col-md-3 text-center reviews">
              <p class="customer-reviews"><a href="#">Customer Reviews</a></p>
                <a href="#" class="link-button-small">Book Hotel<i class="fa fa-map-marker" aria-hidden="true"></i></a>
                <a href="#" class="link-button-small">View Details<i class="fa fa-map-marker" aria-hidden="true"></i></a>
            </div>
    </div>
        
        <div class="single-hotel-wrapper">
          <div class="col-md-12 no-padding hotel-name">
              <h3>Hotel du Collectionneur Arc de Triomphe</h3>
            </div>
            <div class="col-md-3 padding-left-0">
              <img src="<?php echo site_url('assets/images/hotel-1.jpg') ?>" width="100%" alt="" class="img-responsive hotel-img"/>
                <p class="hotel-address"><span>Address : </span>Rue de, Courcelles,<br/>75008 Paris, France.</p>
                <a href="#" class="link-button-small">Show On Map<i class="fa fa-map-marker" aria-hidden="true"></i></a>
            </div>
            <div class="col-md-3 text-center">
              <span class="best-price">Best Price</span>
                <p class="amenity-1">Single Room - Free cancellation</p>
                <p class="breakfast">Breakfast included</p>
                <span class="price-for-hotels"><span>INR 10,347.00</span><br/>Price for 2 nights</span>
            </div>
      <div class="col-md-3 text-center">
              <span class="popular-package">Popular</span>
                <p class="amenity-1">Single Room - Free cancellation</p>
                <p class="breakfast">Breakfast included</p>
                <span class="price-for-hotels"><span>INR 10,347.00</span><br/>Price for 2 nights</span>
            </div>
      <div class="col-md-3 text-center reviews">
              <p class="customer-reviews"><a href="#">Customer Reviews</a></p>
                <a href="#" class="link-button-small">Book Hotel<i class="fa fa-map-marker" aria-hidden="true"></i></a>
                <a href="#" class="link-button-small">View Details<i class="fa fa-map-marker" aria-hidden="true"></i></a>
            </div>
    </div>
        
        
        <div class="single-hotel-wrapper">
          <div class="col-md-12 no-padding hotel-name">
              <h3>Hotel du Collectionneur Arc de Triomphe</h3>
            </div>
            <div class="col-md-3 padding-left-0">
              <img src="<?php echo site_url('assets/images/hotel-1.jpg') ?>" width="100%" alt="" class="img-responsive hotel-img"/>
                <p class="hotel-address"><span>Address : </span>Rue de, Courcelles,<br/>75008 Paris, France.</p>
                <a href="#" class="link-button-small">Show On Map<i class="fa fa-map-marker" aria-hidden="true"></i></a>
            </div>
            <div class="col-md-3 text-center">
              <span class="best-price">Best Price</span>
                <p class="amenity-1">Single Room - Free cancellation</p>
                <p class="breakfast">Breakfast included</p>
                <span class="price-for-hotels"><span>INR 10,347.00</span><br/>Price for 2 nights</span>
            </div>
      <div class="col-md-3 text-center">
              <span class="popular-package">Popular</span>
                <p class="amenity-1">Single Room - Free cancellation</p>
                <p class="breakfast">Breakfast included</p>
                <span class="price-for-hotels"><span>INR 10,347.00</span><br/>Price for 2 nights</span>
            </div>
      <div class="col-md-3 text-center reviews">
              <p class="customer-reviews"><a href="#">Customer Reviews</a></p>
                <a href="#" class="link-button-small">Book Hotel<i class="fa fa-map-marker" aria-hidden="true"></i></a>
                <a href="#" class="link-button-small">View Details<i class="fa fa-map-marker" aria-hidden="true"></i></a>
            </div>
    </div>
        
        </div>
    </div>
</div>