<div class="container text-center">
	<div class="row">
    	<div class="col-md-12">
            <h2>download our app</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's<br/>standard dummy text ever since the 1500s, when an unknown printer took a galley.</p>
        </div>
    </div>
    <div class="row">
    	<div class="col-md-12">
        	<ul class="app-store">
            	<li><a href="#"><img src="<?php echo site_url('assets/images/android-store.png') ?>" alt="" class="img-responsive" /></a></li>
                <li><a href="#"><img src="<?php echo site_url('assets/images/apple-store.png') ?>" alt="" class="img-responsive" /></a></li>
            </ul>
        </div>
    </div>
</div>
