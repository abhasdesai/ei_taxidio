<div class="container text-center">
	<div class="row">
    	<div class="col-md-12">
            <h2>Travel Diaries</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. <br/>Lorem Ipsum has been the industry's standard.</p>
        </div>
    </div>
    <div class="row destinations">
    	<div class="col-md-12 margin-bottom-30 frame-yellow no-padding">
        	<div class="col-md-6 no-padding border-right-white">
            	<img src="<?php echo site_url('assets/images/usa.png') ?>" width="100%" alt="" />
                <h3>USA</h3>
            </div>
            <div class="col-md-6 no-padding border-left-white">
            	<img src="<?php echo site_url('assets/images/canada.png') ?>" width="100%" alt="" />
                <h3>CANADA</h3>
            </div>
        </div>
        <div class="col-md-12 margin-bottom-30 frame-white no-padding">
        	<img src="<?php echo site_url('assets/images/australia2.png') ?>" width="100%" alt="" />
            <h3>AUSTRALIA</h3>
        </div>
        <div class="col-md-12 margin-bottom-30 frame-yellow no-padding">
        	<div class="col-md-6 no-padding border-right-white">
            	<img src="<?php echo site_url('assets/images/france.png') ?>" width="100%" alt="" />
                <h3>FRANCE</h3>
            </div>
            <div class="col-md-6 no-padding border-left-white">
            	<img src="<?php echo site_url('assets/images/london.png') ?>" width="100%" alt="" />
                <h3>LONDON</h3>
            </div>
        </div>
    </div>
</div>
