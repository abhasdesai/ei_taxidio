<div class="container no-padding">
	<div class="row">
    <div class="col-md-12 travel-blogs">
            <h2>Blog Diaries</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. <br/>Lorem Ipsum has been the industry's standard.</p>
        </div>
    	<div class="col-md-4">
        	<div class="grid">
				<figure class="effect-layla">
					<img src="<?php echo site_url('assets/images/10.jpg') ?>" alt="img06" width="100%"/>
					<figcaption>
						<h2>Classic <span> Europe</span></h2>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
						<a href="#">View more</a>
					</figcaption>			
				</figure>
			</div>
        </div>
        <div class="col-md-4">
        	<div class="grid">
				<figure class="effect-layla">
					<img src="<?php echo site_url('assets/images/17.jpg') ?>" alt="img06" width="100%"/>
					<figcaption>
						<h2>Incredible <span> India</span></h2>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
						<a href="#">View more</a>
					</figcaption>			
				</figure>
			</div>
        </div>
        <div class="col-md-4">
        	<div class="grid">
				<figure class="effect-layla">
					<img src="<?php echo site_url('assets/images/27.jpg') ?>" alt="img06" width="100%"/>
					<figcaption>
						<h2>Definitely <span> Dubai</span></h2>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
						<a href="#">View more</a>
					</figcaption>			
				</figure>
			</div>
        </div>
    </div>
    
    <div class="row buttonwrapper">
    	<div class="col-md-12 text-center">
    		<a href="#" class="link-button">View All<i class="fa fa-eye" aria-hidden="true"></i></a>
        </div>
    </div>
    
</div>
