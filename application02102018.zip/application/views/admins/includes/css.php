<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/bootstrap.min.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/font-awesome-4.4.0/css/font-awesome.min.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/ionicons.min.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/AdminLTE.min.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/_all-skins.min.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/iCheck/flat/blue.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/morris.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/jquery-jvectormap-1.2.2.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/daterangepicker-bs3.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/style.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/bootstrap3-wysihtml5.min.css'); ?>">
<script src="<?php echo site_url('assets/admin/js/jQuery-2.1.4.min.js'); ?>"></script>

