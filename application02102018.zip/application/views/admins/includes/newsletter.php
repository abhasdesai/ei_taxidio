<div class="container text-center">
	<div class="row">
    	<div class="col-md-12">
        	<h2>sign up for newsletter</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's<br/>
standard dummy text ever since the 1500s, when an unknown printer took a galley.</p>
        </div>
    </div>
    
    <div class="row formwrapper text-center">
    	<div class="col-md-6 col-md-offset-3 text-center">
            <form role="form1">
                <div class="form-group">
                    <input type="email" class="form-control" placeholder="Email" />
                </div>
                <div class="form-group">
                    <input type="submit" class="form-control" value="SUBSCRIBE" />
                </div>
            </form>
       </div>
    </div>
    
</div>
