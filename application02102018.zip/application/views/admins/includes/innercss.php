<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/bootstrap.min.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/font-awesome-4.4.0/css/font-awesome.min.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/ionicons.min.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/daterangepicker-bs3.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/iCheck/all.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/bootstrap-colorpicker.min.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/bootstrap-timepicker.min.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/select2.min.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/AdminLTE.min.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/_all-skins.min.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/dataTables.bootstrap.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/style.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/jquery.tagit.css'); ?>">
<link rel="stylesheet" href="<?php echo site_url('assets/admin/css/tagit.ui-zendesk.css'); ?>">
<script src="<?php echo site_url('assets/admin/js/jQuery-2.1.4.min.js'); ?>"></script>
