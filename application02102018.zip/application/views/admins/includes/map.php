
  <div class="col-md-12 mapwrapper-title">
    <h2 class="animated bounce">unleash at our destinations</h2>
      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. <br/>Lorem Ipsum has been the industry's standard.</p>
     </div>

  <div class="container-fluid">
      <div class="row">
          <div class="col-md-12 no-padding">
              <div id="wrap">
      <!-- Site content -->
      <div id="content">
        <section id="map-section" class="inner over">
          <div class="editor-window">
            <div class="window-mockup brown"></div>
            <div class="editor-body">
              <code>
                {<br>
                &nbsp;&nbsp;&nbsp;"id": "newlandmark",<br>
                &nbsp;&nbsp;&nbsp;"title": "New Landmark",<br>
                &nbsp;&nbsp;&nbsp;"description": "Creating a new landmark is that easy!",<br>
                &nbsp;&nbsp;&nbsp;"x": "<span class="mapplic-coordinates-x">0.0000</span>",<br>
                &nbsp;&nbsp;&nbsp;"y": "<span class="mapplic-coordinates-y">0.0000</span>",<br>
                &nbsp;&nbsp;&nbsp;...<br>
                }
              </code>
            </div>
          </div>
          <!-- Map -->
          <div class="map-container">
            <div class="window-mockup">
              <div class="window-bar"></div>
            </div>
            <div id="mapplic"></div>
          </div>
         </section>
       </div>
     </div>
            </div>
        </div>
    </div>
