<section class="content-header">
	  <h1>
		<?php echo ucwords($page); ?>
		<small>Control panel</small>
	  </h1>
	  <?php /* ?>
<ol class="breadcrumb">
<li><a href="<?php echo site_url('admins/dashboard'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
<li class="active"><?php echo ucfirst($breadcrumb); ?></li>
</ol>
<?php */?>
</section>
