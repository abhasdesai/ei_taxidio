 <div class="container">
      <div class="row">
          <div class="col-md-6 no-padding">
              <h3>Recommended Hotels for Paris</h3>
            </div>
            <div class="col-md-6 no-padding sort text-right">
                <form>
                       <div class="form-group">
                                <select class="form-control">
                                  <option>Sort By</option>
                                  <option>2</option>
                                  <option>3</option>
                                  <option>4</option>
                                </select>
                       </div>
               </form>
            </div>
        </div>
    </div>