<script src="<?php echo site_url('assets/admin/js/jquery-ui.min.js'); ?>"></script>
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<script src="<?php echo site_url('assets/admin/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/js/raphael-min.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/js/morris.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/js/jquery.sparkline.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/js/jquery-jvectormap-1.2.2.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/js/jquery-jvectormap-world-mill-en.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/js/jquery.knob.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/js/moment.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/js/daterangepicker.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/js/bootstrap3-wysihtml5.all.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/js/jquery.slimscroll.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/js/fastclick.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/js/jquery.validate.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/dist/js/app.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/dist/js/dashboard.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/dist/js/demo.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/js/customscripts.js'); ?>"></script>
<script src="<?php echo site_url('assets/admin/js/jquery.validate.min.js'); ?>"></script>
