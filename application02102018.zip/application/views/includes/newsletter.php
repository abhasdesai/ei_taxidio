<div class="container text-center">
	<div class="row">
    	<div class="col-md-12">
        	<h2>Subscribe to our Blog</h2>
            <p>Being your personal travel itinerary generator, we’d like to give you an occasional buzz and drop by your inbox with a blog we know you’d love to read. We won’t spam. Promise!</p>
        </div>
    </div>

    <div class="row formwrapper text-center">
    	<div class="col-md-6 col-md-offset-3 text-center">

            <form role="form1" id="subscriberform">
                <div class="form-group">
                    <input type="email" name="email" class="form-control" placeholder="Please Enter Your Email" required autocomplete="off" />

                </div>
                <div class="form-group">
                    <input type="submit" class="link-button purple" value="SUBSCRIBE" />
                </div>
            </form>
			<p id="msgsub" style="display:inline-block;width:100%" class="text-center"></p>
       </div>
    </div>

</div>
