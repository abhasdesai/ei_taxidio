<html><head></head><body>
	<table align="center" cellspacing="0" cellpadding="0" border="0" width="600">
<tbody>
	<tr>
		<td align="left" valign="top"><div style="height:90px;text-align:center;"><center><img width="178" height="82" src="<?php echo site_url('assets/images/logo.png') ?>"></center></div></td>
	</tr>
	<tr>
		<td align="center" bgcolor="#f1f69d" valign="top" style="font-family: Arial,Helvetica,sans-serif; font-size: 13px; padding: 10px; border-width: 2px 2px 1px; border-style: solid; border-color: -moz-use-text-color rgb(253, 143, 17) rgb(255, 255, 255); color: rgb(253, 143, 17); background-color: transparent; border-bottom: 2px solid;">
		<table cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-top:10px;">
		<tbody>
			<tr>
			<td align="left" valign="top" style="font-family: Arial,Helvetica,sans-serif; font-size: 13px; color: rgb(0, 0, 0);">
				<div style="font-size: 15px; text-align: left;">
					<p>
						Hi,
					</p>
  				<p>We just received a request to reset the password for this email address.</p>
  				<p>To reset your password, click on this link.(The link will expire in 12 hours.)</p>
  				<p><a href="<?php echo $url; ?>" target='_blank' style='color:blue'><?php echo $url; ?></a></p>
  				<p>If you do not want to reset your password, kindly ignore this email.</p>
				</div>
			</td>
			</tr>
		</tbody>
			</table>
		</td>
	</tr>

</tbody>
</table>
</body></html>
